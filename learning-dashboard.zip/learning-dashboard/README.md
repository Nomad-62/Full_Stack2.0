# Learnly – Learning Platform Dashboard

No install or build step needed.

## Run
Double-click `index.html`, or host the folder anywhere (Netlify, GitHub Pages, any web server).

## Folder
- index.html   – page layout
- css/style.css – styling (light + dark theme, mobile friendly)
- js/data.js   – student, courses, tasks (edit this to change content)
- js/app.js    – renders the dashboard, filters, search, theme toggle

## Connect to a real backend later
In js/app.js, replace the use of `DATA` with data loaded via `fetch('/api/dashboard')`.
