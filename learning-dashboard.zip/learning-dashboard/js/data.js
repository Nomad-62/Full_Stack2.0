// Edit this file to change what the dashboard shows.
// Later you can replace it with a fetch() call to your backend API.
const DATA = {
  student: { name: "Aman", weeklyGoalHours: 10 },
  streakDays: 6,
  studyHours: [1.5, 2, 0.5, 2.5, 1, 3, 1.2],   // Mon..Sun
  courses: [
    { id: 1, title: "Web Development Basics", teacher: "R. Sharma", lessons: 24, done: 18, color: "#1f7a5a", next: "Lesson 19: CSS Grid" },
    { id: 2, title: "Python for Data Analysis", teacher: "P. Kaur",   lessons: 30, done: 9,  color: "#2b6cb0", next: "Lesson 10: Pandas DataFrames" },
    { id: 3, title: "UI Design Fundamentals",  teacher: "S. Mehta",  lessons: 16, done: 16, color: "#9c4f96", next: "" },
    { id: 4, title: "English Communication",   teacher: "A. Bedi",   lessons: 20, done: 4,  color: "#b7791f", next: "Lesson 5: Email Writing" }
  ],
  tasks: [
    { title: "Quiz: JavaScript Arrays", course: "Web Development Basics", due: "Tomorrow", soon: true },
    { title: "Project: Sales Report",   course: "Python for Data Analysis", due: "Fri, 3 Oct", soon: false },
    { title: "Speaking practice",       course: "English Communication", due: "Mon, 6 Oct", soon: false }
  ]
};
