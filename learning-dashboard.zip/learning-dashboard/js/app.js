const $ = id => document.getElementById(id);
const pct = c => Math.round(c.done / c.lessons * 100);
let filter = "all", query = "";

// Greeting
const h = new Date().getHours();
$("greeting").textContent = `${h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening"}, ${DATA.student.name}`;

// Resume card
const cur = DATA.courses.find(c => c.done < c.lessons);
$("resume").innerHTML = cur ? `<div><p>Continue learning</p><h3>${cur.title}</h3><p>${cur.next}</p></div><button>Resume lesson</button>` : `<div><h3>All courses complete</h3></div>`;

// Stats
const totalHrs = DATA.studyHours.reduce((a, b) => a + b, 0);
const stats = [
  ["Courses enrolled", DATA.courses.length],
  ["Lessons completed", DATA.courses.reduce((a, c) => a + c.done, 0)],
  ["Hours this week", totalHrs.toFixed(1)],
  ["Day streak", DATA.streakDays]
];
$("stats").innerHTML = stats.map(s => `<div class="stat"><span>${s[0]}</span><strong>${s[1]}</strong></div>`).join("");

// Weekly goal
$("goalText").textContent = `${totalHrs.toFixed(1)} / ${DATA.student.weeklyGoalHours} hrs`;
setTimeout(() => $("goalBar").style.width = Math.min(100, totalHrs / DATA.student.weeklyGoalHours * 100) + "%", 100);

// Chart
const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const max = Math.max(...DATA.studyHours, 1);
const today = (new Date().getDay() + 6) % 7;
$("chart").innerHTML = DATA.studyHours.map((v, i) =>
  `<div class="col ${i === today ? "today" : ""}" title="${v} hrs"><span>${v}</span><i style="height:0" data-h="${v / max * 100}%"></i><span>${days[i]}</span></div>`).join("");
setTimeout(() => document.querySelectorAll(".col i").forEach(b => b.style.height = b.dataset.h), 100);

// Tasks
$("tasks").innerHTML = DATA.tasks.map(t =>
  `<li><div>${t.title}<small>${t.course}</small></div><span class="badge ${t.soon ? "soon" : ""}">${t.due}</span></li>`).join("");

// Courses
function renderCourses() {
  const list = DATA.courses.filter(c =>
    (filter === "all" || (filter === "done" ? c.done === c.lessons : c.done < c.lessons)) &&
    c.title.toLowerCase().includes(query));
  $("courses").innerHTML = list.length ? list.map(c => `
    <article class="course">
      <div class="thumb" style="background:${c.color}">${c.title.split(" ")[0]}</div>
      <div class="cbody">
        <strong>${c.title}</strong><small>${c.teacher}</small>
        <div class="bar"><span style="width:${pct(c)}%"></span></div>
        <div class="pct"><span>${c.done}/${c.lessons} lessons</span><span>${pct(c)}%</span></div>
      </div>
    </article>`).join("") : `<p class="empty">No courses match. Try a different filter or search.</p>`;
}
document.querySelectorAll(".course .bar span").forEach(() => {});
$("filters").addEventListener("click", e => {
  if (!e.target.dataset.f) return;
  filter = e.target.dataset.f;
  document.querySelectorAll("#filters button").forEach(b => b.classList.toggle("on", b === e.target));
  renderCourses();
});
$("search").addEventListener("input", e => { query = e.target.value.toLowerCase(); renderCourses(); });
renderCourses();

// Theme (remembered between visits)
const root = document.documentElement;
try { root.dataset.theme = localStorage.getItem("theme") || "light"; } catch (e) {}
$("themeBtn").addEventListener("click", () => {
  root.dataset.theme = root.dataset.theme === "dark" ? "light" : "dark";
  try { localStorage.setItem("theme", root.dataset.theme); } catch (e) {}
});

// Mobile menu
$("menuBtn").addEventListener("click", () => $("sidebar").classList.toggle("open"));
