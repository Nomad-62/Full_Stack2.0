# Draft Management System
Full Stack project scaffold.
